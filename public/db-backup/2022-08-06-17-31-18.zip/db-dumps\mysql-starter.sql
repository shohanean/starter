
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_resets_table',1),(3,'2019_08_19_000000_create_failed_jobs_table',1),(4,'2019_12_14_000001_create_personal_access_tokens_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Ervin Hamill','walter.susanna@example.net','2022-07-25 04:04:22','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','ybuHOlhr69','2022-07-25 04:04:22','2022-07-25 04:04:22'),(2,'Tito Hansen','jess20@example.com','2022-07-25 04:04:22','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','xFHz7oqvzb','2022-07-25 04:04:22','2022-07-25 04:04:22'),(3,'Anabel Kuhn','barton.ryder@example.net','2022-07-25 04:04:22','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','RQxSEhbh9u','2022-07-25 04:04:22','2022-07-25 04:04:22'),(4,'Linda Hill','dicki.bailey@example.net','2022-07-25 04:04:22','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','8wvwWXY7Zw','2022-07-25 04:04:22','2022-07-25 04:04:22'),(5,'Mr. Garrett Crooks','laurine10@example.org','2022-07-25 04:04:22','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','R99G7dTAbo','2022-07-25 04:04:22','2022-07-25 04:04:22'),(6,'Ms. Cierra Kiehn V','chansen@example.org','2022-07-25 04:04:22','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','JNXsWs7dPx','2022-07-25 04:04:22','2022-07-25 04:04:22'),(7,'Mr. Kolby Steuber I','fsimonis@example.net','2022-07-25 04:04:22','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','b2rj9skMmZ','2022-07-25 04:04:22','2022-07-25 04:04:22'),(8,'Lamar Wehner','imann@example.net','2022-07-25 04:04:22','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','qDGAK3zGgn','2022-07-25 04:04:22','2022-07-25 04:04:22'),(9,'Elmer Johns','gcruickshank@example.com','2022-07-25 04:04:22','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','1QoEzz1sII','2022-07-25 04:04:22','2022-07-25 04:04:22'),(10,'Ms. Delores Waters II','amanda.heaney@example.net','2022-07-25 04:04:22','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','8hRXfCU9Y8','2022-07-25 04:04:22','2022-07-25 04:04:22'),(11,'Leon Dicki','eusebio49@example.com','2022-07-25 04:04:22','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','WCwV5kCTmt','2022-07-25 04:04:22','2022-07-25 04:04:22'),(12,'Beatrice Doyle DVM','alvena.green@example.com','2022-07-25 04:04:22','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','nXZByq4c2e','2022-07-25 04:04:22','2022-07-25 04:04:22'),(13,'Dr. Mikayla Okuneva III','radams@example.org','2022-07-25 04:04:22','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','An03lwt55q','2022-07-25 04:04:22','2022-07-25 04:04:22'),(14,'Minnie Brakus','ari13@example.com','2022-07-25 04:04:22','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','95534Sndyk','2022-07-25 04:04:22','2022-07-25 04:04:22'),(15,'Prof. Erika Tillman','moore.crystel@example.org','2022-07-25 04:04:22','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','WgsTizG0dh','2022-07-25 04:04:22','2022-07-25 04:04:22'),(16,'Mr. Chadrick Bosco DDS','houston10@example.com','2022-07-25 04:04:22','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','R1cDbrZ8Kx','2022-07-25 04:04:22','2022-07-25 04:04:22'),(17,'Molly Reichel','wrohan@example.com','2022-07-25 04:04:22','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','9JmQWij3Lx','2022-07-25 04:04:22','2022-07-25 04:04:22'),(18,'Ressie Schuster','fhowe@example.com','2022-07-25 04:04:22','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','94PALfHQuZ','2022-07-25 04:04:22','2022-07-25 04:04:22'),(19,'Prof. Vance Walsh','gsenger@example.com','2022-07-25 04:04:22','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','NWEM14LZP2','2022-07-25 04:04:22','2022-07-25 04:04:22'),(20,'Prof. Harley Reinger Sr.','lia10@example.org','2022-07-25 04:04:22','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','8JY47u9PyV','2022-07-25 04:04:22','2022-07-25 04:04:22'),(21,'Geo Johnson','garland.jakubowski@example.org','2022-07-25 04:04:22','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','HJ3x4PEmwI','2022-07-25 04:04:22','2022-07-25 04:04:22'),(22,'Ada Cartwright','jcormier@example.net','2022-07-25 04:04:22','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','EbQdXyZ3uA','2022-07-25 04:04:22','2022-07-25 04:04:22'),(23,'Austen Dicki','warren19@example.net','2022-07-25 04:04:22','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','83wmZxHM8L','2022-07-25 04:04:22','2022-07-25 04:04:22'),(24,'Frederik Borer IV','kessler.lula@example.com','2022-07-25 04:04:22','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','Wa07dv5xQO','2022-07-25 04:04:22','2022-07-25 04:04:22'),(25,'Camryn Bosco MD','ashley.buckridge@example.org','2022-07-25 04:04:22','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','FzvtSCk7S3','2022-07-25 04:04:22','2022-07-25 04:04:22'),(26,'Prof. Everardo Bayer III','herman.cary@example.com','2022-07-25 04:04:22','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','hATtUrStLt','2022-07-25 04:04:22','2022-07-25 04:04:22'),(27,'Eldora Barton','bertram.torp@example.com','2022-07-25 04:04:22','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','n3fMiPuHsc','2022-07-25 04:04:22','2022-07-25 04:04:22'),(28,'Bethany Bode Jr.','hand.marley@example.org','2022-07-25 04:04:22','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','lcTAdYq2rw','2022-07-25 04:04:22','2022-07-25 04:04:22'),(29,'Ralph Labadie MD','lavina45@example.net','2022-07-25 04:04:22','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','UaYZnqyhyN','2022-07-25 04:04:22','2022-07-25 04:04:22'),(30,'Thurman King','janae03@example.net','2022-07-25 04:04:22','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','XORK23Y9Zn','2022-07-25 04:04:22','2022-07-25 04:04:22'),(31,'Mya Barrows','ryan.tanner@example.net','2022-07-25 04:04:22','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','fMbLl01pmK','2022-07-25 04:04:22','2022-07-25 04:04:22'),(32,'Mrs. Marian Moore','romaine36@example.net','2022-07-25 04:04:22','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','4RniuVQ1SD','2022-07-25 04:04:22','2022-07-25 04:04:22'),(33,'Miss Sienna Koss','becker.brooklyn@example.com','2022-07-25 04:04:22','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','sqSdc7tYDp','2022-07-25 04:04:22','2022-07-25 04:04:22'),(34,'Dr. Laverna Bode','cooper58@example.com','2022-07-25 04:04:22','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','55dMACCKRu','2022-07-25 04:04:22','2022-07-25 04:04:22'),(35,'Catharine Lindgren','rzieme@example.org','2022-07-25 04:04:22','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','xsUyyD0QLI','2022-07-25 04:04:22','2022-07-25 04:04:22'),(36,'Virgil Dibbert V','welch.emily@example.com','2022-07-25 04:04:22','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','8iJqbj3eHG','2022-07-25 04:04:22','2022-07-25 04:04:22'),(37,'Fredy Jacobs','vkozey@example.org','2022-07-25 04:04:22','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','D6VrSiHdtt','2022-07-25 04:04:22','2022-07-25 04:04:22'),(38,'Myrtie Wuckert','meghan.gutkowski@example.com','2022-07-25 04:04:22','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','85DXDr7L5o','2022-07-25 04:04:22','2022-07-25 04:04:22'),(39,'Ernestine Grady','vnienow@example.com','2022-07-25 04:04:22','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','3oyp7zjNt2','2022-07-25 04:04:22','2022-07-25 04:04:22'),(40,'Patricia Powlowski IV','kadin79@example.net','2022-07-25 04:04:22','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','GzZlO2hr0V','2022-07-25 04:04:22','2022-07-25 04:04:22'),(41,'Ms. Felicia Braun V','strosin.gwen@example.com','2022-07-25 04:04:22','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','HCnyfVa2zw','2022-07-25 04:04:22','2022-07-25 04:04:22'),(42,'Shawna Romaguera','mason20@example.org','2022-07-25 04:04:22','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','yAiIKBusqD','2022-07-25 04:04:22','2022-07-25 04:04:22'),(43,'Prof. Candida Wilderman','donnelly.curtis@example.net','2022-07-25 04:04:22','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','VKlN8hA8xt','2022-07-25 04:04:22','2022-07-25 04:04:22'),(44,'Baby Stroman V','raymundo14@example.org','2022-07-25 04:04:22','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','Ili14w7SZT','2022-07-25 04:04:22','2022-07-25 04:04:22'),(45,'Xzavier Walsh','stephanie.kemmer@example.org','2022-07-25 04:04:22','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','oI6izkxtvn','2022-07-25 04:04:22','2022-07-25 04:04:22'),(46,'Ashton Daniel MD','kacie35@example.net','2022-07-25 04:04:22','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','JHC9lcuYs2','2022-07-25 04:04:22','2022-07-25 04:04:22'),(47,'Helmer Pfannerstill','ross79@example.org','2022-07-25 04:04:22','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','tRmOHdx8EE','2022-07-25 04:04:22','2022-07-25 04:04:22'),(48,'Leopold McLaughlin','tgottlieb@example.net','2022-07-25 04:04:22','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','Xk4RNqtC4M','2022-07-25 04:04:22','2022-07-25 04:04:22'),(49,'Mr. Clinton Schowalter','vconnelly@example.net','2022-07-25 04:04:22','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','5koKtzNXcP','2022-07-25 04:04:22','2022-07-25 04:04:22'),(50,'Brooke Hermiston','elliot.kessler@example.net','2022-07-25 04:04:22','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','xnXtL5IQ2Q','2022-07-25 04:04:22','2022-07-25 04:04:22'),(51,'Brett Weaver','jejiriqy@mailinator.com','2022-07-25 04:04:22','$2y$10$ZokqnavhpTYeh8sbELPs9OnaQBNIquriYjLknv532/ViQ0JgFTO/O',NULL,'2022-08-03 07:28:16','2022-08-03 07:28:16'),(52,'Hamilton Maynard','viwazumyk@mailinator.com','2022-07-25 04:04:22','$2y$10$8NR8Y1xPiH1J6fB6YfcMiOEGeZn5I7TC/kuPSR0SxNArdz5cNiMVm',NULL,'2022-08-03 21:32:11','2022-08-03 21:32:11'),(53,'Cecilia Zamora','kidid@mailinator.com','2022-07-25 04:04:22','$2y$10$jGIH1JNAy.FgxsFK.ZA1NOMa3/W2ZZ/lhFsHnz66d3F.CkbluBk26',NULL,'2022-08-04 02:42:02','2022-08-04 02:42:02'),(54,'Gregory Walls','zeridenero@mailinator.com','2022-08-05 11:29:12','$2y$10$BgO9WO7kDcOsZt8r7rrpc.OW5Su2L7QBL1qEFvMNk70U0ewfsWj0a',NULL,'2022-08-06 11:27:03','2022-08-06 11:27:03');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

